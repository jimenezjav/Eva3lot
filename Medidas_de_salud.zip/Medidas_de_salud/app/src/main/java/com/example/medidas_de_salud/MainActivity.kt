package com.example.medidas_de_salud

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.medidas_de_salud.Vistas.AlertasFragment
import com.example.medidas_de_salud.Vistas.ContactosFragment
import com.example.medidas_de_salud.Vistas.InicioFragment
import com.example.medidas_de_salud.Vistas.MonitoreoFragment
import com.example.medidas_de_salud.Vistas.PerfilFragment
import com.example.medidas_de_salud.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    //Configurar viewBinding
    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //Cargar un fragment por defecto
        if (savedInstanceState == null){
            supportFragmentManager.beginTransaction().replace(R.id.fragment_container, InicioFragment()).commit()
        }
        binding.bottomNavigation.setOnItemSelectedListener {
            when(it.itemId){
                R.id.item_1 -> {
                    supportFragmentManager.beginTransaction().replace(R.id.fragment_container, InicioFragment()).commit()
                    true
                }
                R.id.item_2 -> {
                    supportFragmentManager.beginTransaction().replace(R.id.fragment_container, MonitoreoFragment()).commit()
                    true
                }
                R.id.item_3 -> {
                    supportFragmentManager.beginTransaction().replace(R.id.fragment_container, ContactosFragment()).commit()
                    true
                }
                R.id.item_4 -> {
                    supportFragmentManager.beginTransaction().replace(R.id.fragment_container, AlertasFragment()).commit()
                    true
                }
                R.id.item_5 -> {
                    supportFragmentManager.beginTransaction().replace(R.id.fragment_container, PerfilFragment()).commit()
                    true
                }
                else -> false

            }
        }

        binding.bottomNavigation.setOnItemReselectedListener {
            when(it.itemId){
                R.id.item_1 -> {
                    true
                }
                R.id.item_2 -> {
                    true
                }
                R.id.item_3 -> {

                    true
                }
                R.id.item_4 -> {

                    true
                }
                R.id.item_5 -> {

                    true
                }
                else -> false

            }
        }

    }
}